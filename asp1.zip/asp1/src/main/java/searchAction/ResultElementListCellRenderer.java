package searchAction;

import com.intellij.icons.AllIcons;
import com.intellij.ui.ColoredListCellRenderer;
import com.intellij.ui.JBColor;
import com.intellij.ui.SimpleTextAttributes;
import com.intellij.ui.speedSearch.SpeedSearchUtil;
import com.intellij.util.text.Matcher;
import com.intellij.util.text.MatcherHolder;
import com.intellij.util.ui.UIUtil;
import org.jetbrains.annotations.NotNull;
import searchAction.model.SearchResultElement;

import javax.swing.*;
import java.awt.*;

/**
 * Created by hoainguyen on 12/31/16.
 */
public class ResultElementListCellRenderer extends JPanel implements ListCellRenderer, MatcherHolder {
    private Matcher matcher;

    public ResultElementListCellRenderer() {
        super(new BorderLayout());
    }

    @Override
    public void setPatternMatcher(Matcher matcher) {
        this.matcher = matcher;
    }

    @Override
    public Component getListCellRendererComponent(JList list, Object value, int index,
                                                  boolean isSelected, boolean cellHasFocus) {
        removeAll();

        // Right
        DefaultListCellRenderer rightRenderer = new RightCellRenderer();
        Component rightComponent = rightRenderer.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
        add(rightComponent, BorderLayout.EAST);

        // Space
        JPanel spacer = new JPanel();
        spacer.setBorder(BorderFactory.createEmptyBorder(0, 2, 0, 2));
        add(spacer, BorderLayout.CENTER);

        // Left
        ListCellRenderer leftRenderer = new LeftCellRenderer(matcher);
        Component leftComponent = leftRenderer.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
        add(leftComponent, BorderLayout.WEST);

        // Background color
        Color bg = isSelected ? UIUtil.getListSelectionBackground() : leftComponent.getBackground();
        setBackground(bg);
        rightComponent.setBackground(bg);
        spacer.setBackground(bg);

        return this;
    }

    private static class LeftCellRenderer extends ColoredListCellRenderer {
        private final Matcher matcher;

        private LeftCellRenderer(Matcher matcher) {
            this.matcher = matcher;
        }

        @Override
        protected void customizeCellRenderer(@NotNull JList list, Object value, int index, boolean selected, boolean hasFocus) {
            Color bgColor = UIUtil.getListBackground();
            setPaintFocusBorder(hasFocus && UIUtil.isToUseDottedCellBorder());

            if (value instanceof SearchResultElement) {
                SearchResultElement element = (SearchResultElement) value;
                String stringKeyText = "(" + element.getName() + ")";
                String text = new StringEllipsisPolicy().ellipsizeText(element.getValue(), matcher);

                SimpleTextAttributes nameAttributes = new SimpleTextAttributes(Font.PLAIN, list.getForeground());
                SpeedSearchUtil.appendColoredFragmentForMatcher(text, this, nameAttributes, matcher, bgColor, selected);
                append(" " + stringKeyText, new SimpleTextAttributes(Font.PLAIN, JBColor.GRAY));
            }

            setBackground(selected ? UIUtil.getListSelectionBackground() : bgColor);
        }
    }

    private class RightCellRenderer extends DefaultListCellRenderer {

        RightCellRenderer() {
            super();
        }

        public Component getListCellRendererComponent(JList list, Object value, int index,
                                                      boolean isSelected, boolean cellHasFocus) {
            Component component = super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
            customize(value, isSelected);
            return component;
        }

        private void customize(Object value, boolean selected) {
            if (value instanceof SearchResultElement) {
                SearchResultElement element = (SearchResultElement) value;
                setIcon(AllIcons.Modules.SourceFolder); //NEED CORRECT
                setText(element.getParentDirName());
                setBorder(BorderFactory.createEmptyBorder(0, 0, 0, UIUtil.getListCellHPadding()));
                setHorizontalTextPosition(2);
                setBackground(selected ? UIUtil.getListSelectionBackground() : UIUtil.getListBackground()); //NEED CORRECT
                setForeground(selected ? UIUtil.getListSelectionForeground() : UIUtil.getInactiveTextColor()); //NEED CORRECT

                if (UIUtil.isUnderNimbusLookAndFeel()) { //NEED CORRECT
                    setOpaque(false);
                }
            }
        }
    }
}
