package searchAction;

import com.intellij.ide.util.gotoByName.ChooseByNameFilterConfiguration;
import com.intellij.openapi.components.*;
import com.intellij.openapi.project.Project;
import searchAction.model.SearchResultElement;

/**
 * Created by hoainguyen on 12/31/16.
 */
@State(
        name = "SearchConfiguration",
        storages = {@Storage(value = StoragePathMacros.WORKSPACE_FILE)}
)
public class SearchConfiguration extends ChooseByNameFilterConfiguration<SearchResultElement>{
    public static SearchConfiguration getInstance(Project project) {
        return ServiceManager.getService(project, SearchConfiguration.class);
        //NEED CORRECT
    }

    @Override
    protected String nameForElement(SearchResultElement type) {
        return type.getName();
    }
}
